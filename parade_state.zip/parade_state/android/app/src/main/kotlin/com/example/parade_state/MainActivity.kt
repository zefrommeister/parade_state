package com.example.parade_state

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
